package br.com.cotemig.instagramfake.model;

/**
 * Created by dirceu on 06/04/2018.
 */

public class ModelUsuario {

    private String usuario;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}
