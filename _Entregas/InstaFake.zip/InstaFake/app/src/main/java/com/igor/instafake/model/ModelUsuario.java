package com.igor.instafake.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by 71600388 on 02/04/2018.
 */

public class ModelUsuario {
    private String usuario;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}
